package adrian.recluta6.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;


@Named
@SessionScoped
public class Evento implements Serializable {

	private static final long serialVersionUID = -2884950568538542843L;

	private String nombre;
	private String recinto;
	private String dia;
	private String hora;
	private Integer boletos;
	
	private List<Evento> even = new ArrayList<Evento>();
	
	
	
	public String getNombre() {
		return nombre;
	}




	public void setNombre(String nombre) {
		this.nombre = nombre;
	}




	public String getRecinto() {
		return recinto;
	}




	public void setRecinto(String recinto) {
		this.recinto = recinto;
	}




	public String getDia() {
		return dia;
	}




	public void setDia(String dia) {
		this.dia = dia;
	}




	public String getHora() {
		return hora;
	}




	public void setHora(String hora) {
		this.hora = hora;
	}




	public Integer getBoletos() {
		return boletos;
	}




	public void setBoletos(Integer boletos) {
		this.boletos = boletos;
	}




	public String agregar() {
		Evento evento = new Evento();
		
		evento.setNombre(nombre);
		evento.setRecinto(recinto);
		evento.setDia(dia);
		evento.setHora(hora);
		evento.setBoletos(boletos);
		
		even.add(evento);
		System.out.println("Eventos Registrados:"+ even.size());
		
		
		
	return "index";	
		
	}
		
	
	
}
